from PyQt5 import QtGui
from PyQt5.QtWidgets import QApplication,QWidget, QVBoxLayout, QPushButton, QFileDialog , QLabel, QLineEdit,QHBoxLayout
from PyQt5.QtGui import QPixmap,QKeyEvent
from PyQt5.QtCore import QCoreApplication,QTimer
import sys
from detector.shapedetector import ShapeDetector
from detector.colorlabeler import ColorLabeler
import argparse
import imutils
import cv2
from imutils import contours
from scipy.spatial import distance as dist
from imutils import perspective
import numpy as np

def midpoint(ptA, ptB):
	return ((ptA[0] + ptB[0]) * 0.5, (ptA[1] + ptB[1]) * 0.5)




class Window(QWidget):
    def __init__(self):
        super().__init__()

        self.title = "Feature Detection"
        self.top = 200
        self.left = 500
        self.width = 400
        self.height = 300


        self.InitWindow()


    def InitWindow(self):
        self.filepath = ""
        self.cnt = None
        self.setWindowIcon(QtGui.QIcon("icon.png"))
        self.setWindowTitle(self.title)
        self.setGeometry(self.left, self.top, self.width, self.height)

        vbox = QVBoxLayout()
        self.hbox = QHBoxLayout()
        self.btn1 = QPushButton("Open")
        self.btn1.clicked.connect(self.getImage)
        self.btn2 = QPushButton("detect shape")
        self.btn2.clicked.connect(self.shapencolor)
        self.btn3 = QPushButton("detect dimensions")
        self.btn3.clicked.connect(self.getsize)
        self.textbox = QLineEdit(self)
        self.label = QLabel("Hello")
        self.label1 = QLabel("reference object width:")
        self.hbox.addWidget(self.btn1)
        self.hbox.addWidget(self.btn2)
        self.hbox.addWidget(self.btn3)
        self.hbox.addWidget(self.label1)
        self.hbox.addWidget(self.textbox)
        self.timer=QTimer()
        vbox.addLayout(self.hbox)
        
        vbox.addWidget(self.label)

        


        self.setLayout(vbox)

        self.show()

    def getImage(self):
        fname = QFileDialog.getOpenFileName(self, 'Open file','/', "Image files (*.jpg *.gif *.png)")
        self.filepath = fname[0]
        imagePath = fname[0]
        pixmap = QPixmap(imagePath)
        self.label.setPixmap(QPixmap(pixmap))
        self.resize(pixmap.width(), pixmap.height())
    def getroi (self):
        image = cv2.imread(self.filepath)
        r = cv2.selectROI("reference object selector", image, False, False)
        imCrop = image[int(r[1]):int(r[1]+r[3]), int(r[0]):int(r[0]+r[2])]
        gray = cv2.cvtColor(imCrop, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (7, 7), 0)
        # perform edge detection, then perform a dilation + erosion to
        # close gaps in between object edges
        edged = cv2.Canny(gray, 50, 100)
        edged = cv2.dilate(edged, None, iterations=1)
        edged = cv2.erode(edged, None, iterations=1)
        cv2.imshow("edged",edged)
        # find contours in the edge map
        cnts = cv2.findContours(edged.copy(), cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_SIMPLE)
        cnts = imutils.grab_contours(cnts)
        box = cv2.minAreaRect(cnts[0])
        box = cv2.cv.BoxPoints(box) if imutils.is_cv2() else cv2.boxPoints(box)
        box = np.array(box, dtype="int")
        	# unpack the ordered bounding box, then compute the midpoint
        # between the top-left and top-right coordinates, followed by
        # the midpoint between bottom-left and bottom-right coordinates
        
        (tl, tr, br, bl) = box
        (tltrX, tltrY) = midpoint(tl, tr)
        (blbrX, blbrY) = midpoint(bl, br)

        # compute the midpoint between the top-left and top-right points,
        # followed by the midpoint between the top-righ and bottom-right
        (tlblX, tlblY) = midpoint(tl, bl)
        (trbrX, trbrY) = midpoint(tr, br)
        dA = dist.euclidean((tltrX, tltrY), (blbrX, blbrY))
        dB = dist.euclidean((tlblX, tlblY), (trbrX, trbrY))
        tt = self.textbox.text()
        cv2.destroyAllWindows()
        pixelsPerMetric = dB / float(tt)
        print("pixelsPerMetric")
        return pixelsPerMetric



    def getsize(self):
        pixelsPerMetric = self.getroi()
        image = cv2.imread(self.filepath)
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (7, 7), 0)
        # perform edge detection, then perform a dilation + erosion to
        # close gaps in between object edges
        edged = cv2.Canny(gray, 50, 100)
        edged = cv2.dilate(edged, None, iterations=1)
        edged = cv2.erode(edged, None, iterations=1)
        
        # find contours in the edge map
        cnts = cv2.findContours(edged.copy(), cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_SIMPLE)
        cnts = imutils.grab_contours(cnts)
        for c in cnts:
            # if the contour is not sufficiently large, ignore it
            if cv2.contourArea(c) < 100:
                continue

            # compute the rotated bounding box of the contour
            
            box = cv2.minAreaRect(c)
            box = cv2.cv.BoxPoints(box) if imutils.is_cv2() else cv2.boxPoints(box)
            box = np.array(box, dtype="int")

            # order the points in the contour such that they appear
            # in top-left, top-right, bottom-right, and bottom-left
            # order, then draw the outline of the rotated bounding
            # box
            box = perspective.order_points(box)
            cv2.drawContours(image, [box.astype("int")], -1, (255,182,193), 2)

            # loop over the original points and draw them
            for (x, y) in box:
                cv2.circle(image, (int(x), int(y)), 3, (0, 0, 255), -1)

            # unpack the ordered bounding box, then compute the midpoint
            # between the top-left and top-right coordinates, followed by
            # the midpoint between bottom-left and bottom-right coordinates
            (tl, tr, br, bl) = box
            (tltrX, tltrY) = midpoint(tl, tr)
            (blbrX, blbrY) = midpoint(bl, br)

            # compute the midpoint between the top-left and top-right points,
            # followed by the midpoint between the top-righ and bottom-right
            (tlblX, tlblY) = midpoint(tl, bl)
            (trbrX, trbrY) = midpoint(tr, br)

            # draw the midpoints on the image
            cv2.circle(image, (int(tltrX), int(tltrY)), 3, (255, 0, 0), -1)
            cv2.circle(image, (int(blbrX), int(blbrY)), 3, (255, 0, 0), -1)
            cv2.circle(image, (int(tlblX), int(tlblY)), 3, (255, 0, 0), -1)
            cv2.circle(image, (int(trbrX), int(trbrY)), 3, (255, 0, 0), -1)

            # draw lines between the midpoints
            cv2.line(image, (int(tltrX), int(tltrY)), (int(blbrX), int(blbrY)),
                 (255,0,255), 1)
            cv2.line(image, (int(tlblX), int(tlblY)), (int(trbrX), int(trbrY)),
                 (255,0,255), 1)

            # compute the Euclidean distance between the midpoints
            dA = dist.euclidean((tltrX, tltrY), (blbrX, blbrY))
            dB = dist.euclidean((tlblX, tlblY), (trbrX, trbrY))

            # if the pixels per metric has not been initialized, then
            # compute it as the ratio of pixels to supplied metric
            # (in this case, inches)

            # compute the size of the object
            dimA = dA / pixelsPerMetric
            dimB = dB / pixelsPerMetric
            cv2.destroyAllWindows()
            # draw the object sizes on the image
            cv2.putText(image, "{:.1f}in".format(dimB),
                (int(tltrX - 15), int(tltrY - 10)), cv2.FONT_HERSHEY_SIMPLEX,
                0.5, (255,255,255), 1)
            cv2.putText(image, "{:.1f}in".format(dimA),
                (int(trbrX + 10), int(trbrY)), cv2.FONT_HERSHEY_SIMPLEX,
                0.5, (255,255,255), 1)
            img = QtGui.QImage(image.data,image.shape[1], image.shape[0], QtGui.QImage.Format_RGB888).rgbSwapped()        
            self.label.setPixmap(QPixmap.fromImage(img))
            self.resize(img.width(), img.height())
            


    def shapencolor(self):
        print(self.filepath)
        image = cv2.imread(self.filepath)
        resized = image
        
        

        # blur the resized image slightly, then convert it to both
        # grayscale and the L*a*b* color spaces
        blurred = cv2.GaussianBlur(resized, (5, 5), 0)
     

        gray = cv2.cvtColor(blurred, cv2.COLOR_BGR2GRAY)
        lab = cv2.cvtColor(blurred, cv2.COLOR_BGR2LAB)
        cv2.imshow("LAB",lab)
        retval2,thresh= cv2.threshold(gray,70,255,cv2.THRESH_BINARY)
        

        
        # find contours in the thresholded image
        cnts = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL,
                cv2.CHAIN_APPROX_SIMPLE)
        cnts = imutils.grab_contours(cnts)
        (cnts, _) = contours.sort_contours(cnts)
        self.cnt = cnts
        # initialize the shape detector and color labeler
        sd = ShapeDetector()
        cl = ColorLabeler()

        # loop over the contours
        for c in cnts:
                # compute the center of the contour
            
                M = cv2.moments(c)
                if  (M["m00"]>0):
                    cX = int((M["m10"] / M["m00"]) )
                    cY = int((M["m01"] / M["m00"]) )

                    # detect the shape of the contour and label the color
                    shape = sd.detect(c)
                    color = cl.label(lab, c)

                    # multiply the contour (x, y)-coordinates by the resize ratio,
                    # then draw the contours and the name of the shape and labeled
                    # color on the image
                    c = c.astype("float")
                    
                    c = c.astype("int")
                    text = "{} {}".format(color,shape)
                    
                    cv2.drawContours(image, [c], -1, (255,0,255), 2)
                    cv2.putText(image, text, (cX-50, cY),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255,255,255), 1)


                    # unpack the ordered bounding box, then compute the midpoint
                    # between the top-left and top-right coordinates, followed by


                    # draw the midpoints on the image



                    
                    img = QtGui.QImage(image.data,image.shape[1], image.shape[0], QtGui.QImage.Format_RGB888).rgbSwapped()        
                    self.label.setPixmap(QPixmap.fromImage(img))
                    self.resize(img.width(), img.height())
        
                

                

App = QApplication(sys.argv)
window = Window()
sys.exit(App.exec())